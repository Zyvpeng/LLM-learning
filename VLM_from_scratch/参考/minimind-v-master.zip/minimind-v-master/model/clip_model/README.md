* 需要把clip-vit-base-patch32模型下载到此目录下

```bash
git clone https://hf-mirror.com/openai/clip-vit-base-patch32
```