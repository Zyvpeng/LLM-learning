* 需要把siglip-base-patch16-224模型下载到此目录下

```bash
git clone https://hf-mirror.com/google/siglip-base-patch16-224
```